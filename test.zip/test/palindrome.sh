#!/bin/bash

echo "Enter a string:"
read string

# Check if the string is empty
if [ -z "$string" ]; then
    echo "String should not be NULL."
    exit 1
fi

len=${#string}
i=0
flag=true

while [ $i -lt $len ]; do
    # Get characters from both ends of the string
    char1="${string:$i:1}"
    char2="${string:$((len - 1 - i)):1}"

    # If characters are not equal, set flag to false and exit loop
    if [ "$char1" != "$char2" ]; then
        flag=false
        break
    fi

    # Move to the next characters
    ((i++))
done

if $flag; then
    echo "String is a palindrome."
else
    echo "String is not a palindrome."
fi
