#include <iostream>
#include <pthread.h>
#include <mutex>
#include <fstream>
#include <string>

using namespace std;

// Define mutex and condition variables
pthread_mutex_t mutex_lock = PTHREAD_MUTEX_INITIALIZER;
pthread_cond_t can_read = PTHREAD_COND_INITIALIZER;
pthread_cond_t can_write = PTHREAD_COND_INITIALIZER;

int readers_count = 0; // To keep track of active readers
bool writer_writing = false; // To track if a writer is currently writing

// Function prototypes
void *reader(void *);
void *writer(void *);

int main() {
    // Create threads for readers and writers
    pthread_t readers[5], writers[5];
    int i;

    for (i = 0; i < 5; ++i) {
        pthread_create(&readers[i], NULL, reader, NULL);
    }

    //  5 writer threads
    for (i = 0; i < 5; ++i) {
        pthread_create(&writers[i], NULL, writer, NULL);
    }

    // Join threads
    for (i = 0; i < 5; ++i) {
        pthread_join(readers[i], NULL);
        pthread_join(writers[i], NULL);
    }

    return 0;
}

void *reader(void *) {
    // Acquire lock
    pthread_mutex_lock(&mutex_lock);
    
    // Increment the number of active readers
    ++readers_count;
    
    // Wait for the writer to finish if there is any writer writing
    while (writer_writing) {
        cout << "Reader " << pthread_self() << " waiting for writer to finish writing." << endl;
        pthread_cond_wait(&can_read, &mutex_lock);
    }

    cout << "Reader " << pthread_self() << " starts reading." << endl;

    // Release lock
    pthread_mutex_unlock(&mutex_lock);
    
    // Read from file
    ifstream file("ai_65.txt");
    string line;
    while (getline(file, line)) {
        cout << "Reader " << pthread_self() << " read: " << line << endl;
    }
    file.close();
    
    // Acquire lock
    pthread_mutex_lock(&mutex_lock);
    
    // Decrement the number of active readers
    --readers_count;
    
    // Signal writer if there are no more readers
    if (readers_count == 0) {
        cout << "Reader " << pthread_self() << " is the last reader." << endl;
        pthread_cond_signal(&can_write);
    }

    // Release lock
    pthread_mutex_unlock(&mutex_lock);

    pthread_exit(NULL);
}

void *writer(void *) {
    // Acquire lock
    pthread_mutex_lock(&mutex_lock);
    
    // Wait if there are active readers or a writer writing
    while (readers_count > 0 || writer_writing) {
        cout << "Writer " << pthread_self() << " waiting for other readers/writers to finish." << endl;
        pthread_cond_wait(&can_write, &mutex_lock);
    }
    
    cout << "Writer " << pthread_self() << " starts writing." << endl;

    // Set writer_writing flag
    writer_writing = true;
    
    // Release lock
    pthread_mutex_unlock(&mutex_lock);
    
    // Write to file
    ofstream file("ai_65.txt", ios::app);
    file << "Writer " << pthread_self() << " wrote." << endl;
    file.close();
    
    // Acquire lock
    pthread_mutex_lock(&mutex_lock);
    
    // Reset writer_writing flag
    writer_writing = false;


    pthread_cond_broadcast(&can_read);
    pthread_cond_signal(&can_write);

    // Release lock
    pthread_mutex_unlock(&mutex_lock);

    pthread_exit(NULL);
}
    
