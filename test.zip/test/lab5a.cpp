#include <iostream>
#include <unistd.h>
#include <sys/wait.h>

using namespace std;

int childProcess(int processID, int incrementTimes, int sleepDuration) {
    int counter = 0;
    for (int i = 0; i < incrementTimes; ++i) {
        counter++;
    }
    cout << "Child process " << processID << ": Incremented counter " << incrementTimes << " times." << endl;
    sleep(sleepDuration); // Sleep for specified duration
    return counter;
}

int main() {
    int i1, i2, i3;

    // Create child processes
    pid_t pid1 = fork();
    if (pid1 == 0) {
        return childProcess(1, 10, 4);
    } else if (pid1 < 0) {
        cerr << "Fork failed." << endl;
        return 1;
    }

    pid_t pid2 = fork();
    if (pid2 == 0) {
        return childProcess(2, 90, 5);
    } else if (pid2 < 0) {
        cerr << "Fork failed." << endl;
        return 1;
    }

    pid_t pid3 = fork();
    if (pid3 == 0) {
        return childProcess(3, 177, 7);
    } else if (pid3 < 0) {
        cerr << "Fork failed." << endl;
        return 1;
    }

    // Wait for all child processes to finish
    waitpid(pid1, &i1, 0);

    // Print final values
    cout << "Final values:" << endl;
    cout << "i1: " << i1 << endl;
    cout << "i2: " << i2 << endl;
    cout << "i3: " << i3 << endl;

    return 0;
}
