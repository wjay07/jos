#include <iostream>
#include <fcntl.h>   // for open
#include <unistd.h>  // for read, write, close
#include <sys/types.h>
#include <sys/stat.h>
#include <cstring>   // for strlen
#include <cerrno>    // for errno

using namespace std;

int main() {
    const char* filename = "testfile.txt";

    // Open the file for writing
    int fd = open(filename, O_WRONLY | O_CREAT | O_TRUNC, S_IRUSR | S_IRGRP | S_IROTH); // Read-only permissions
    if (fd == -1) {
        cerr << "Error: Unable to open file for writing." << endl;
        return 1;
    }

    // Write data to the file
    const char* buffer = "Hello, world!\n";
    ssize_t bytesWritten = write(fd, buffer, strlen(buffer));
    if (bytesWritten == -1) {
        cerr << "Error: Unable to write to file." << endl;
        close(fd);
        return 1;
    }

    // Close the file
    close(fd);

    // Open the file for reading
    fd = open(filename, O_RDONLY);
    if (fd == -1) {
        cerr << "Error: Unable to open file for reading." << endl;
        return 1;
    }

    // Read data from the file
    char readBuffer[128];
    ssize_t bytesRead = read(fd, readBuffer, sizeof(readBuffer));
    if (bytesRead == -1) {
        cerr << "Error: Unable to read from file." << endl;
        close(fd);
        return 1;
    }

    // Close the file
    close(fd);

    // Display the read data
    cout << "Read from file: " << readBuffer << endl;

    // Simulate read-only condition
    if (chmod(filename, S_IRUSR | S_IRGRP | S_IROTH) == -1) { // Make the file read-only
        cerr << "Error: Unable to change file permissions." << endl;
        return 1;
    }

    // Retry writing with read-only condition
    fd = open(filename, O_WRONLY);
    if (fd == -1) {
        cerr << "Error: Unable to open file for writing (read-only condition)." << endl;
        return 1;
    }

    // Attempt to write data to the file (should fail due to read-only condition)
    bytesWritten = write(fd, buffer, strlen(buffer));
    if (bytesWritten == -1) {
        cout << "Failed to write to file (read-only condition)." << endl;
    }

    // Close the file
    close(fd);

    // Change permissions to allow writing
    if (chmod(filename, S_IRUSR | S_IWUSR | S_IRGRP | S_IROTH) == -1) { // Grant write permissions
        cerr << "Error: Unable to change file permissions." << endl;
        return 1;
    }

    // Open the file for writing again
    fd = open(filename, O_WRONLY);
    if (fd == -1) {
        cerr << "Error: Unable to open file for writing." << endl;
        return 1;
    }

    // Write data to the file after changing permissions
    bytesWritten = write(fd, buffer, strlen(buffer));
    if (bytesWritten != -1) {
        cout << "Successfully wrote to file after changing permissions." << endl;
    } else {
        cerr << "Error: Unable to write to file even after updating permissions." << endl;
        close(fd);
        return 1;
    }

    // Close the file
    close(fd);

    return 0;
}

