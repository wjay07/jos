#include <iostream>
#include <pthread.h>
#include <semaphore.h>
#include <unistd.h>
#include <ctime>

#define BUFFER_SIZE 5
#define TIMEOUT_SECONDS 10 // Timeout period in seconds

sem_t bfull, bempty;
pthread_mutex_t mutex;
bool running = true; // Flag to control thread execution
int producedItems = 0, consumedItems = 0; // Track produced and consumed items

void *producer(void *arg) {
    time_t startTime = time(NULL); // Record start time
    while (running) {
        sem_wait(&bempty);
        pthread_mutex_lock(&mutex);

        // Produce item
        std::cout << "Producing item" << std::endl;
        producedItems++;

        pthread_mutex_unlock(&mutex);
        sem_post(&bfull);
        usleep(1000000); // Sleep for 1 second

        // Check if timeout has occurred
        if (difftime(time(NULL), startTime) > TIMEOUT_SECONDS) {
            std::cout << "Producer thread timed out." << std::endl;
            break;
        }
    }
    std::cout << "Producer thread exited." << std::endl;
    pthread_exit(NULL);
}

void *consumer(void *arg) {
    time_t startTime = time(NULL); // Record start time
    while (running) {
        sem_wait(&bfull);
        pthread_mutex_lock(&mutex);

        // Consume item
        std::cout << "Consuming item" << std::endl;
        consumedItems++;

        pthread_mutex_unlock(&mutex);
        sem_post(&bempty);
        usleep(1000000); // Sleep for 1 second

        // Check if timeout has occurred
        if (difftime(time(NULL), startTime) > TIMEOUT_SECONDS) {
            std::cout << "Consumer thread timed out." << std::endl;
            break;
        }
    }
    std::cout << "Consumer thread exited." << std::endl;
    pthread_exit(NULL);
}

int main() {
    pthread_t producerThread, consumerThread;
    
    // Initialize semaphores and mutex
    sem_init(&bfull, 0, 0);
    sem_init(&bempty, 0, BUFFER_SIZE);
    pthread_mutex_init(&mutex, NULL);

    std::cout << "Program started." << std::endl;
    std::cout << "Buffer size: " << BUFFER_SIZE << std::endl;

    // Create producer and consumer threads
    pthread_create(&producerThread, NULL, producer, NULL);
    pthread_create(&consumerThread, NULL, consumer, NULL);

    // Wait for threads to complete or timeout
    sleep(TIMEOUT_SECONDS);

    // Set running flag to false to terminate threads
    running = false;

    // Join threads
    pthread_join(producerThread, NULL);
    pthread_join(consumerThread, NULL);

    // Destroy semaphores and mutex
    sem_destroy(&bfull);
    sem_destroy(&bempty);
    pthread_mutex_destroy(&mutex);

    std::cout << "Produced items: " << producedItems << std::endl;
    std::cout << "Consumed items: " << consumedItems << std::endl;
    std::cout << "Program terminated." << std::endl;

    return 0;
}
