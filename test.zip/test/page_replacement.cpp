// CPP
#include <bits/stdc++.h>
using namespace std;


bool search(int key, vector<int>& fr)
{
	for (int i = 0; i < fr.size(); i++)
		if (fr[i] == key)
			return true;
	return false;
}


int predict(int pg[], vector<int>& fr, int pn, int index)
{
	// Store the index of pages which are going
	// to be used recently in future
	int res = -1, farthest = index;
	for (int i = 0; i < fr.size(); i++) {
		int j;
		for (j = index; j < pn; j++) {
			if (fr[i] == pg[j]) {
				if (j > farthest) {
					farthest = j;
					res = i;
				}
				break;
			}
		}

		// If a page is never referenced in future,
		// return it.
		if (j == pn)
			return i;
	}

	// If all of the frames were not in future,
	// return any of them, we return 0. Otherwise
	// we return res.
	return (res == -1) ? 0 : res;
}

void optimalPage(int pg[], int pn, int fn)
{

	vector<int> fr;

	// Traverse through page reference array
	// and check for miss and hit.
	int hit = 0;
	for (int i = 0; i < pn; i++) {

		// Page found in a frame : HIT
		if (search(pg[i], fr)) {
			hit++;
			continue;
		}

		// Page not found in a frame : MISS

		// If there is space available in frames.
		if (fr.size() < fn)
			fr.push_back(pg[i]);

		// Find the page to be replaced.
		else {
			int j = predict(pg, fr, pn, i + 1);
			fr[j] = pg[i];
		}
	}
	cout<<endl<<"Optimal : ";
	cout << "No. of hits = " << hit << endl;
	cout << "No. of misses = " << pn - hit << endl;
}

// Function to find page faults using indexes
int LRU_pageFaults(int pages[], int n, int capacity)
{

    unordered_set<int> s;

    // To store least recently used indexes
    // of pages.
    unordered_map<int, int> indexes;

    // Start from initial page
    int page_faults = 0;
    for (int i=0; i<n; i++)
    {
        // Check if the set can hold more pages
        if (s.size() < capacity)
        {
            // Insert it into set if not present
            // already which represents page fault
            if (s.find(pages[i])==s.end())
            {
                s.insert(pages[i]);

                // increment page fault
                page_faults++;
            }

            // Store the recently used index of
            // each page
            indexes[pages[i]] = i;
        }

        // If the set is full then need to perform lru
        // i.e. remove the least recently used page
        // and insert the current page
        else
        {
            // Check if current page is not already
            // present in the set
            if (s.find(pages[i]) == s.end())
            {
                // Find the least recently used pages
                // that is present in the set
                int lru = INT_MAX, val;
                for (auto it=s.begin(); it!=s.end(); it++)
                {
                    if (indexes[*it] < lru)
                    {
                        lru = indexes[*it];
                        val = *it;
                    }
                }

                // Remove the indexes page
                s.erase(val);

                // insert the current page
                s.insert(pages[i]);

                // Increment page faults
                page_faults++;
            }

            // Update the current page index
            indexes[pages[i]] = i;
        }

    }
cout << "No. of hits = " << page_faults << endl;
	cout << "No. of misses = " << n - page_faults << endl;
    return page_faults;
}



//bool search(int key, vector<int>& fr) {
//    for (int i = 0; i < fr.size(); i++)
//        if (fr[i] == key)
//            return true;
//    return false;
//}

int predictLFU(int pg[], const unordered_set<int>& fr, unordered_map<int, int>& freq, int pn, int index) {
    int res = -1, minFreq = INT_MAX;
    for (int page : fr) {
        if (freq[page] < minFreq) {
            minFreq = freq[page];
            res = page;
        }
    }
    return res;
}
void MRU_pageFaults(int pages[], int n, int capacity) {
    unordered_set<int> s;
    unordered_map<int, int> indexes;

    int page_faults = 0;
    for (int i = 0; i < n; i++) {
        if (s.size() < capacity) {
            if (s.find(pages[i]) == s.end()) {
                s.insert(pages[i]);
                page_faults++;
            }
            indexes[pages[i]] = i;
        } else {
            if (s.find(pages[i]) == s.end()) {
                int mruPage = -1, maxIndex = INT_MIN;
                for (auto it = s.begin(); it != s.end(); ++it) {
                    if (indexes[*it] > maxIndex) {
                        mruPage = *it;
                        maxIndex = indexes[*it];
                    }
                }
                s.erase(mruPage);
                s.insert(pages[i]);
                page_faults++;
            }
            indexes[pages[i]] = i;
        }
    }

    cout << "No. of hits = " << page_faults << endl;
    cout << "No. of misses = " << n - page_faults << endl;
}
void LFU_pageFaults(int pages[], int n, int capacity) {
    unordered_set<int> s;
    unordered_map<int, int> freq;
    unordered_map<int, int> indexes;

    int page_faults = 0;
    for (int i = 0; i < n; i++) {
        if (s.size() < capacity) {
            if (s.find(pages[i]) == s.end()) {
                s.insert(pages[i]);
                page_faults++;
                freq[pages[i]]++;
            }
            indexes[pages[i]] = i;
        } else {
            if (s.find(pages[i]) == s.end()) {
                int lfuPage = predictLFU(pages, s, freq, n, i + 1);
                s.erase(lfuPage);
                s.insert(pages[i]);
                page_faults++;
                freq[pages[i]]++;
            }
            indexes[pages[i]] = i;
        }
    }
    cout<<endl<<"LFU :";
    cout << "No. of hits = " << page_faults << endl;
    cout << "No. of misses = " << n - page_faults << endl;
}

void FIFO_pageFaults(int pages[], int n, int capacity) {
    unordered_set<int> s;
    queue<int> pageQueue; // Queue to store pages in order of arrival

    int page_faults = 0;
    for (int i = 0; i < n; i++) {
        if (s.size() < capacity) {
            if (s.find(pages[i]) == s.end()) {
                s.insert(pages[i]);
                pageQueue.push(pages[i]);
                page_faults++;
            }
        } else {
            if (s.find(pages[i]) == s.end()) {
                int frontPage = pageQueue.front();
                pageQueue.pop();
                s.erase(frontPage);
                s.insert(pages[i]);
                pageQueue.push(pages[i]);
                page_faults++;
            }
        }
    }

    cout << "No. of hits = " << page_faults << endl;
    cout << "No. of misses = " << n - page_faults << endl;
}

void MFU_pageFaults(int pages[], int n, int capacity) {
    unordered_set<int> s;
    unordered_map<int, int> freq;
    unordered_map<int, int> indexes;

    int page_faults = 0;
    for (int i = 0; i < n; i++) {
        if (s.size() < capacity) {
            if (s.find(pages[i]) == s.end()) {
                s.insert(pages[i]);
                page_faults++;
            }
            freq[pages[i]]++;
            indexes[pages[i]] = i;
        } else {
            if (s.find(pages[i]) == s.end()) {
                int mfuPage = -1, maxFreq = INT_MIN;
                for (auto it = s.begin(); it != s.end(); ++it) {
                    if (freq[*it] > maxFreq || (freq[*it] == maxFreq && indexes[*it] < indexes[mfuPage])) {
                        mfuPage = *it;
                        maxFreq = freq[*it];
                    }
                }
                s.erase(mfuPage);
                s.insert(pages[i]);
                page_faults++;
            }
            freq[pages[i]]++;
            indexes[pages[i]] = i;
        }
    }

    cout << "No. of hits = " << page_faults << endl;
    cout << "No. of misses = " << n - page_faults << endl;
}
// Driver Function
int main()
{
	int pg[] = {2,5,0,7,8,3,7,4,5,3,7,4,6,5,8,7,3,4,5,7,7,8,7,2,3,9,4,7,5,2,9,3,9,9,9,4,7,0,9,8,2,3,4,9,8,3,2,5,9,8,7,3,9,5,7,5,2,3,4,5,2,3,4,5,5,8,9,8,0,9,5,2,3,4,5,2,4,4,5,4,4,4,5,5,4,9,8,9,9,9,4,5,8,8,8,8,4,0,3,9,0,9,2,0,9,0,9,0,8,0,9,8,9,8,2,5,2,8,8,8,8,2,3,4,5,9,8,0,2,5,8,2,3,4,0,5,8,2,0,9,3,4,0,9,8,9,2,5,0,9,9,4,5,3,2,4,5,2,3,4,5,2,3,4,4,4,3,3,4,8,9,8,9,4,0,4,5,0,9,8,5,4,9,8,9,8,8,9,8,8,9,0,8,9,8,9,0};
	int pn = sizeof(pg) / sizeof(pg[0]);
	int fn = 4;
	optimalPage(pg, pn, fn);
	cout<<endl<<"LRU: ";
    int capacity = 4;
    int temp = LRU_pageFaults(pg, pn, 4);
//        cout << "LFU: ";
    LFU_pageFaults(pg, pn, capacity);

        cout <<endl<< "FIFO: ";
    FIFO_pageFaults(pg, pn, capacity);

  cout <<endl<< "MRU: ";
    MFU_pageFaults(pg, pn, capacity);
    cout<<endl<<endl;
    	int pg1[] = {4,3,5,5,5,5,5,5,4,8,8,4,4,8,8,8,8,8,4,8,8,5,7,5,7,5,7,5,7,7,7,5,9,0,0,0,0,0,2,7,4,7,7,4,3,8,8,9,3,2,9,8,2,9,8,9,9,8,3,7,4,9,7,2,9,8,2,9,8,9,8,8,0};
	pn = sizeof(pg1) / sizeof(pg1[0]);
	fn = 4;
	optimalPage(pg1, pn, fn);
	cout<<endl<<"LRU: ";
     capacity = 4;
    int temp1 = LRU_pageFaults(pg1, pn, 4);
//        cout << "LFU: ";
    LFU_pageFaults(pg1, pn, capacity);

        cout <<endl<< "FIFO: ";
    FIFO_pageFaults(pg1, pn, capacity);

  cout <<endl<< "MRU: ";
    MFU_pageFaults(pg1, pn, capacity);

	return 0;
}
