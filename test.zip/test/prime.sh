#!/bin/bash

echo "Enter a number:"
read num

if [ $num -le 1 ]; then
    echo "$num is not a prime number."
    exit
fi

is_prime=1
for (( i=2; i<=num/2; i++ ))
do
    if [ $((num%i)) -eq 0 ]; then
        is_prime=0
        break
    fi
done

if [ $is_prime -eq 1 ]; then
    echo "$num is a prime number."
else
    echo "$num is not a prime number."
fi








# #!/bin/bash

# echo "Enter a number to check if it's prime:"
# read num

# # Check if the input is a positive integer greater than 1
# if ! [[ "$num" =~ ^[1-9][0-9]*$ ]]; then
#     echo "Error: Please enter a positive integer greater than 1."
#     exit 1
# fi

# # Function to check if a number is prime
# is_prime() {
#     local n=$1
#     if [ $n -eq 2 ] || [ $n -eq 3 ]; then
#         return 0
#     fi
#     if [ $(($n % 2)) -eq 0 ] || [ $(($n % 3)) -eq 0 ]; then
#         return 1
#     fi
#     local i=5
#     local w=2
#     while [ $((i * i)) -le $n ]; do
#         if [ $(($n % i)) -eq 0 ]; then
#             return 1
#         fi
#         i=$((i + w))
#         w=$((6 - w))
#     done
#     return 0
# }

# # Call the function to check if the number is prime
# if is_prime "$num"; then
#     echo "$num is a prime number."
# else
#     echo "$num is not a prime number."
# fi
