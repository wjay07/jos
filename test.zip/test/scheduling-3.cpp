#include <iostream>
#include <algorithm>
#include <vector>
#include <climits>

using namespace std;

class Process {
private:
    int id, bt, at, ct, tat, wt, priority;

public:
    // input arrival time and burst time
    void input(vector<Process>&, int);


    void inputForPriority(vector<Process>&, int);
    void calcFCFS(vector<Process>&);
    void calcSJF(vector<Process>&);
    void calcSJFPreemptive(vector<Process>&);
    void calcPriorityScheduling(vector<Process>&);
    void calcPrioritySchedulingPreemptive(vector<Process>&);
    void calcRoundRobin(vector<Process>&, int);

    // Function to display process details
    void show(const vector<Process>&);

    // Comparator functions
    static bool compareArrival(const Process&, const Process&);
    static bool compareBurst(const Process&, const Process&);
    static bool comparePriority(const Process&, const Process&);
};

// Comparator function to sort processes based on arrival time
bool Process::compareArrival(const Process& p1, const Process& p2) {
    return p1.at < p2.at;
}

// Comparator function to sort processes based on burst time
bool Process::compareBurst(const Process& p1, const Process& p2) {
    return p1.bt < p2.bt;
}

// Comparator function to sort processes based on priority
bool Process::comparePriority(const Process& p1, const Process& p2) {
    return p1.priority < p2.priority;
}

// Function to input arrival time and burst time
void Process::input(vector<Process>& p, int n) {
    p.resize(n);
    for (int i = 0; i < n; ++i) {
        cout << "\nEnter arrival time for process " << i + 1 << ":\n";
        cin >> p[i].at;
        cout << "Enter burst time for process " << i + 1 << ":\n";
        cin >> p[i].bt;
        p[i].id = i + 1;
    }
}

// Function to input priorities
void Process::inputForPriority(vector<Process>& p, int n) {
    p.resize(n);
    for (int i = 0; i < n; ++i) {
        cout << "Enter priority for process " << i + 1 << ":\n"; // Input priority
        cin >> p[i].priority;
        p[i].id = i + 1;
    }
}

// Function to calculate completion time, turnaround time, and waiting time using First Come First Serve (FCFS) algorithm
void Process::calcFCFS(vector<Process>& p) {
    int sum = 0;
    sum = sum + p[0].at;
    for (size_t i = 0; i < p.size(); ++i) {
        sum = sum + p[i].bt;
        p[i].ct = sum;
        p[i].tat = p[i].ct - p[i].at;
        p[i].wt = p[i].tat - p[i].bt;
        if (i < p.size() - 1 && sum < p[i + 1].at) {
            int t = p[i + 1].at - sum;
            sum = sum + t;
        }
    }
}

// Function to calculate completion time, turnaround time, and waiting time using Shortest Job First (SJF) algorithm
void Process::calcSJF(vector<Process>& p) {
    // Sort processes based on arrival time
    sort(p.begin(), p.end(), compareArrival);

    int n = p.size();
    vector<int> remainingTime(n);
    vector<int> arrivalOrder(n);

    for (int i = 0; i < n; ++i) {
        remainingTime[i] = p[i].bt;
        arrivalOrder[i] = i; // Initialize arrival order
    }

    int currentTime = 0;
    int completed = 0;

    while (completed < n) {
        bool done = true;
        for (int i = 0; i < n; ++i) {
            int idx = arrivalOrder[i]; // Process index according to arrival order
            if (p[idx].at <= currentTime && remainingTime[idx] > 0) {
                done = false; // At least one process is not done
                currentTime += remainingTime[idx];
                remainingTime[idx] = 0;
                p[idx].ct = currentTime;
                p[idx].tat = p[idx].ct - p[idx].at;
                p[idx].wt = p[idx].tat - p[idx].bt;
                completed++;
                break; // Exit the loop after executing one process
            }
        }
        if (done) {
            // If no process can be executed at current time, move to the next arrival time
            int nextArrival = INT_MAX;
            for (int i = 0; i < n; ++i) {
                if (remainingTime[i] > 0 && p[i].at < nextArrival) {
                    nextArrival = p[i].at;
                }
            }
            currentTime = nextArrival;
        }
    }
}

// // Function to calculate completion time, turnaround time, and waiting time using preemptive Shortest Job First (SJF) algorithm
// void Process::calcSJFPreemptive(vector<Process>& p) {
//     sort(p.begin(), p.end(), compareArrival);
//     int currentTime = p[0].at;
//     int completed = 0;
//     vector<int> remainingTime(p.size());
//     for (size_t i = 0; i < p.size(); ++i) {
//         remainingTime[i] = p[i].bt;
//     }

//     while (completed < p.size()) {
//         int shortestIdx = -1;
//         int shortestBurst = INT_MAX;
//         for (size_t i = 0; i < p.size(); ++i) {
//             if (p[i].at <= currentTime && remainingTime[i] > 0 && remainingTime[i] < shortestBurst) {
//                 shortestIdx = i;
//                 shortestBurst = remainingTime[i];
//             }
//         }

//         if (shortestIdx != -1) {
//             remainingTime[shortestIdx]--;
//             currentTime++;

//             if (remainingTime[shortestIdx] == 0) {
//                 completed++;
//                 p[shortestIdx].ct = currentTime;
//                 p[shortestIdx].tat = p[shortestIdx].ct - p[shortestIdx].at;
//                 p[shortestIdx].wt = p[shortestIdx].tat - p[shortestIdx].bt;
//             }
//         } else {
//             currentTime++;
//         }
//     }
// }

// Function to calculate completion time, turnaround time, and waiting time using non-preemptive priority scheduling algorithm
void Process::calcPriorityScheduling(vector<Process>& p) {
    // Sort processes based on arrival time and priority
    sort(p.begin(), p.end(), compareArrival);

    int n = p.size();
    vector<int> remainingTime(n);
    vector<int> arrivalOrder(n); // To maintain the order of process arrival

    for (int i = 0; i < n; ++i) {
        remainingTime[i] = p[i].bt;
        arrivalOrder[i] = i; // Initialize arrival order
    }

    int currentTime = 0;
    int completed = 0;

    while (completed < n) {
        bool done = true;
        for (int i = 0; i < n; ++i) {
            int idx = arrivalOrder[i]; // Process index according to arrival order
            if (p[idx].at <= currentTime && remainingTime[idx] > 0) {
                done = false; // At least one process is not done
                currentTime += remainingTime[idx];
                remainingTime[idx] = 0;
                p[idx].ct = currentTime;
                p[idx].tat = p[idx].ct - p[idx].at;
                p[idx].wt = p[idx].tat - p[idx].bt;
                completed++;
            }
        }
        if (done) {
            // If no process can be executed at current time, move to the next arrival time
            int nextArrival = INT_MAX;
            for (int i = 0; i < n; ++i) {
                if (remainingTime[i] > 0 && p[i].at < nextArrival) {
                    nextArrival = p[i].at;
                }
            }
            currentTime = nextArrival;
        }
    }
}


// Function to calculate completion time, turnaround time, and waiting time using preemptive priority scheduling algorithm
// Function to calculate completion time, turnaround time, and waiting time using preemptive priority scheduling algorithm
//void Process::calcPrioritySchedulingPreemptive(vector<Process>& p) {
//
//}
// Function to calculate completion time, turnaround time, and waiting time using preemptive priority scheduling algorithm
void Process::calcPrioritySchedulingPreemptive(vector<Process>& p) {
    int currentTime = 0;
    int completed = 0;
    vector<int> remainingTime(p.size());
    for (size_t i = 0; i < p.size(); ++i) {
        remainingTime[i] = p[i].bt;
    }

    while (completed < p.size()) {
        int highestPriorityIdx = -1;
        int highestPriority = INT_MAX;
        for (size_t i = 0; i < p.size(); ++i) {
            if (p[i].at <= currentTime && remainingTime[i] > 0 && p[i].priority < highestPriority) {
                highestPriorityIdx = i;
                highestPriority = p[i].priority;
            }
        }

        if (highestPriorityIdx != -1) {
            remainingTime[highestPriorityIdx]--;
            currentTime++;

            if (remainingTime[highestPriorityIdx] == 0) {
                completed++;
                p[highestPriorityIdx].ct = currentTime;
                p[highestPriorityIdx].tat = p[highestPriorityIdx].ct - p[highestPriorityIdx].at;
                p[highestPriorityIdx].wt = p[highestPriorityIdx].tat - p[highestPriorityIdx].bt;
            }
        } else {
            currentTime++;
        }
    }
}

void Process::calcRoundRobin(vector<Process>& p, int quantum) {
    int n = p.size();
    vector<int> remainingTime(n);
    vector<int> arrivalTime(n);
    vector<int> startTime(n);
    vector<int> completionTime(n);

    for (int i = 0; i < n; ++i) {
        remainingTime[i] = p[i].bt;
        arrivalTime[i] = p[i].at;
    }

    int currentTime = 0;
    int completed = 0;

    while (completed < n) {
        for (int i = 0; i < n; ++i) {
            if (remainingTime[i] > 0) {
                if (remainingTime[i] > quantum) {
                    currentTime += quantum;
                    remainingTime[i] -= quantum;
                } else {
                    currentTime += remainingTime[i];
                    remainingTime[i] = 0;
                    completionTime[i] = currentTime;
                    completed++;
                }
            }
        }
    }

    for (int i = 0; i < n; ++i) {
        p[i].ct = completionTime[i];
        p[i].tat = p[i].ct - arrivalTime[i] +1;
        p[i].wt = p[i].tat - p[i].bt;
        if(p[i].wt <0){
            p[i].wt =0;
        }
    }
}

// Function to display process details
void Process::show(const vector<Process>& p) {
    cout << "Process\tArrival\tBurst\tWaiting\tTurn Around\tCompletion\n";
    for (const auto& proc : p) {
        cout << "  P[" << proc.id << "]\t  " << proc.at << "\t" << proc.bt << "\t" << proc.wt << "\t   " << proc.tat << "\t\t" << proc.ct << "\n";
    }
}

int main() {
    int n;
    char choice; // Change choice to char type
    cout << "\nEnter the number of processes in your system:\n";
    cin >> n;
    vector<Process> p(n);
    Process f;
    f.input(p, n);
    Main_menu :
    cout << "\nWhich scheduling algorithm do you want to apply?\n";
    cout << "1. First Come First Serve (FCFS)\n";
    cout << "2. Shortest Job First (SJF)\n";
    cout << "3. Priority Scheduling -Non Preemptive\n";
    cout << "4. Priority Scheduling - Preemptive\n";
    cout << "5. Round Robin (RR)\n";
    cin >> choice;
    switch (choice) {
     case '1': // Use character constants
        f.calcFCFS(p);
        break;
     case '2':
        f.calcSJF(p); // Change to calcSJF function
        break;
     case '3':
        f.inputForPriority(p, n);
        f.calcPriorityScheduling(p); // Corrected to calcPriorityScheduling
        break;
     case '4':
        f.inputForPriority(p, n);
        f.calcPrioritySchedulingPreemptive(p); // Corrected to calcPriorityScheduling
        break;
     case '5':
        int quantum;
        cout << "Enter time quantum for Round Robin scheduling:\n";
        cin >> quantum;
        f.calcRoundRobin(p, quantum);
        break;
     default:
        cout << "Invalid choice! Applying FCFS by default.\n";
        f.calcFCFS(p);
    }

    f.show(p);
    goto Main_menu;
    return 0;
}
